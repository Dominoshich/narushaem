-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Янв 16 2024 г., 10:54
-- Версия сервера: 10.8.4-MariaDB
-- Версия PHP: 8.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `narushaem`
--

-- --------------------------------------------------------

--
-- Структура таблицы `statements`
--

CREATE TABLE `statements` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `vehiclenumber` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `status` varchar(30) DEFAULT 'Новое'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `statements`
--

INSERT INTO `statements` (`id`, `user_id`, `vehiclenumber`, `description`, `status`) VALUES
(1, 1, 'E521XE', 'Протаранил меня пидорас', 'Новое'),
(2, 3, 'E151XE', 'asdasdasd', 'Новое'),
(3, 3, 'Х123УХ', 'Твою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататараТвою трубу трататататара', 'Новое'),
(4, 2, 'E922XE', 'ААААААААААААААААААААА КРОКОДИЛ ЗА РУЛЕМ\r\nААААААААААААААААААААА КРОКОДИЛ ЗА РУЛЕМ\r\nААААААААААААААААААААА КРОКОДИЛ ЗА РУЛЕМ\r\nААААААААААААААААААААА КРОКОДИЛ ЗА РУЛЕМ\r\nААААААААААААААААААААА КРОКОДИЛ ЗА РУЛЕМ\r\nААААААААААААААААААААА КРОКОДИЛ ЗА РУЛЕМ\r\nААААААААААААААААААААА КРОКОДИЛ ЗА РУЛЕМ\r\nААААААААААААААААААААА КРОКОДИЛ ЗА РУЛЕМ\r\nААААААААААААААААААААА КРОКОДИЛ ЗА РУЛЕМ\r\nААААААААААААААААААААА КРОКОДИЛ ЗА РУЛЕМ\r\nААААААААААААААААААААА КРОКОДИЛ ЗА РУЛЕМ\r\nААААААААААААААААААААА КРОКОДИЛ ЗА РУЛЕМ\r\nААААААААААААААААААААА КРОКОДИЛ ЗА РУЛЕМ\r\nААААААААААААААААААААА КРОКОДИЛ ЗА РУЛЕМ\r\nААААААААААААААААААААА КРОКОДИЛ ЗА РУЛЕМ\r\nААААААААААААААААААААА КРОКОДИЛ ЗА РУЛЕМ', 'Новое'),
(6, 3, 'E151уE', 'ФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФФ', 'Новое'),
(8, 3, 'E151XE', 'ыфвфывфыыфвфывфыыфвфывфыыфвфывфыыфвфывфыыфвфывфыыфвфывфыыфвфывфыыфвфывфыыфвфывфыыфвфывфыыфвфывфыыфвфывфы', 'Отклонено'),
(12, 3, 'E152XE', 'abbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb', 'Принято'),
(13, 3, 'У121ЧУ', 'abbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb', 'Принято'),
(14, 2, 'E150XE', 'abbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbb', 'Новое'),
(15, 3, 'У122ЧУ', 'abbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbabbbbbbbb', 'Отклонено');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`, `fullname`, `phone`, `email`) VALUES
(1, 'aboba', '12345', 'Денис Пидорас Михайлович', '+79009157980', 'pidor29@gmail.com'),
(2, 'pidoras', '123123123', 'Denis', '+79009153121', 'asmdasd@mail.ru'),
(3, 'aligator', '123123', 'Deniska', '+79009132232', 'mailsuch@mail.ru'),
(4, 'pidorasss', '123123123', 'Denis', '+79009153121', 'asmsdasssssd@mail.ru'),
(5, 'copp', 'password', 'Администратор', '+8800553535', 'admin@mail.ru');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `statements`
--
ALTER TABLE `statements`
  ADD PRIMARY KEY (`id`),
  ADD KEY `UserID` (`user_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `Login` (`login`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `statements`
--
ALTER TABLE `statements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `statements`
--
ALTER TABLE `statements`
  ADD CONSTRAINT `statements_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
