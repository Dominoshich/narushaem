<?php
session_start();
$_SESSION = null;
error_reporting(-1);
function debug($value)
{
    echo "<pre>";
    var_dump($value);
    echo "</pre>";
}
require_once('connection.php');
 // Подключение к бд с помощью PDO
$regexp_valid = "/[^a-zA-Z0-9.,@а-яА-Я -]+/"; // регулярка для проверка входных данных

$regexp_valid_phone = '/^\+\d{11}$/';// регулярка для проверка телефона
// Избовляюсь от нотисов в HTML, т.к. поля после неверного заполения таблицы не стираются и не надо вводить все данные заново
$login = '';
$name = '';
$email = '';
$password = '';
$phone = '';

$msg = "Поля могут содержать цифры, буквы, сивол - @";
$i=0;
// Если отправилась форма методом POST начинаем проверку данных и заносим в БД. Форма на этой же странице.
// Если заходить на страницу просто по адресу а не отправкой формы то мы на нее поподаем методом GET
if($_SERVER['REQUEST_METHOD'] == 'POST' && count($_POST) > 0){
    // Обработка данных из массива POST
    $login = trim($_POST['login']);
    $email = strtolower(trim($_POST['email']));
    $name = trim($_POST['name']);
    $password = trim($_POST['pwd']);
    $phone= trim($_POST['phone']);



    // проверка на корректность
    if(((bool)preg_match($regexp_valid, $login)) || $name  == '' ){
        $msg_login = "Ошибка, name $login - не корректный";
        $_SESSION['error_login']=$msg_login;
        $i++;
    }

    if(((bool)preg_match($regexp_valid, $name)) || $name  == '' ){
        $msg_name = "Ошибка, name $name - не корректный";
        $_SESSION['error_name']=$msg_name;
        $i++;
    }
    if(((bool)preg_match($regexp_valid, $email)) ||  $email  == ''){
        $msg_log = "Ошибка, почта $email - не корректная";
        $_SESSION['error_log']=$msg_log;
        $i++;
    }

    if(((bool)preg_match($regexp_valid, $password)) || strlen($password) <= 3 ||  $password == ''){
        $msg_pwd = "Ошибка, пароль не корректный";
        $_SESSION['error_pwd']=$msg_pwd;
        $i++;
    }
    if (!preg_match($regexp_valid_phone, $phone) || $phone == '') {
        $msg_phone = "Ошибка, номер телефона не корректный";
        $_SESSION['error_phone'] = $msg_phone;
        $i++;
    }
    if(((bool)preg_match($regexp_valid, $email)) ||  $email  == ''){
        $msg_email = "Ошибка, почта $email - не корректный";
        $_SESSION['error_email']=$msg_email;
        $i++;
    }


}
    if ($i==0){
// Проверка на идентичность с БД (что бы пользователь с одими и теми же данными не зарестрировался два раза)
// Проверка логина
$check_login =  mysqli_query($connect,"SELECT * FROM `users` WHERE `login`='$login'");
if($check_login->num_rows>0){
    $res_check_login=mysqli_fetch_assoc($check_login);
}else{
    $res_check_login=0;
}

$check_email =  mysqli_query($connect,"SELECT * FROM `users` WHERE `email`='$email'");
if($check_email->num_rows>0){
    $res_check_email=mysqli_fetch_assoc($check_email);
}else{
    $res_check_email=0;
}


if($res_check_email > 0){
    $msg_emaildouble = "Пользователь с такой почтой уже существует";
    $_SESSION['error_reg_emaildouble']=$msg_emaildouble;

} elseif ($res_check_login > 0) {
    $msg_logdouble = "Пользователь с таким логином уже существует";
    $_SESSION['error_reg_logdouble']=$msg_logdouble;

}
else {
    $result = mysqli_query ($connect,"INSERT INTO users (login, password, fullname, phone, email) VALUES ('$login', '$password', '$name', '$phone', '$email')");
    if($result){
        $msg_success = "Регистрация успешно завершена";
        $_SESSION['success']=$msg_success;

    }else{
        $msg_nothattime = 'Чево то не получилось добавить в бд ошибка какая-то';
        $_SESSION['error_reg_nothattime']=$msg_nothattime;
       echo $login."<br>";
        echo  $name."<br>";
        echo  $email."<br>";
        echo  $password."<br>";
        echo  $phone."<br>";
    }

}}else{
        debug($_SESSION);

//        header("Location: ./Registration.php ");
    }
$_SESSION['error_reg']='prooverka';
debug($_SESSION);

//header("Location: ./Applications.php ");

?>
