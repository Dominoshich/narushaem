<?php
$connect=mysqli_connect('localhost', 'root','', 'narushaem');
if(!$connect){
    die('Error connect to DataBase');
}
$conn = new mysqli('localhost', 'root', '', 'narushaem');
?>

